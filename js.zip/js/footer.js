const createFooter = () => {
    let footer = document.querySelector('footer');

    footer.innerHTML = `
    <div class="footer-content">
    <img src="img/img/img/light-logo.png" class="logo" alt="">
    <div class="footer-ul-container">
       <ul class="category">
            <li class="category-title">men</li>
            <li><a href="#" class="footer-link">t-shirts</a></li>
            <li><a href="#" class="footer-link">t-swetshirts</a></li>
            <li><a href="#" class="footer-link">shirts</a></li>
            <li><a href="#" class="footer-link">jeans</a></li>
            <li><a href="#" class="footer-link">trousers</a></li>
            <li><a href="#" class="footer-link">shoes</a></li>
            <li><a href="#" class="footer-link">causuals</a></li>
            <li><a href="#" class="footer-link">formals</a></li>
            <li><a href="#" class="footer-link">soprts</a></li>
            <li><a href="#" class="footer-link">watches</a></li>





        </ul>  
        <ul class="category">
            <li class="category-title">women</li>
            <li><a href="#" class="footer-link">t-shirts</a></li>
            <li><a href="#" class="footer-link">t-swetshirts</a></li>
            <li><a href="#" class="footer-link">shirts</a></li>
            <li><a href="#" class="footer-link">jeans</a></li>
            <li><a href="#" class="footer-link">trousers</a></li>
            <li><a href="#" class="footer-link">shoes</a></li>
            <li><a href="#" class="footer-link">causuals</a></li>
            <li><a href="#" class="footer-link">formals</a></li>
            <li><a href="#" class="footer-link">sports</a></li>
            <li><a href="#" class="footer-link">watches</a></li>





        </ul>                                          
        


    </div>
    <p class="footer-title">about company</p>
    <p class="info">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis reiciendis ea perspiciatis et tempore vero cupiditate tenetur sapiente amet nobis quo sunt, assumenda sed aperiam culpa minus velit, id quod harum adipisci, incidunt eaque vitae. Magnam expedita, laborum dignissimos doloremque odit voluptatibus officia in corporis nemo non doloribus atque quidem est earum provident magni repudiandae natus reiciendis placeat sunt sit unde distinctio modi rem. Qui dolorem quibusdam rerum enim voluptates consequatur neque alias ipsam deleniti optio, animi perferendis voluptas magni molestias tempora temporibus, sapiente deserunt explicabo porro. Debitis nam veritatis, fuga eligendi porro molestias aliquam inventore, id voluptates nisi sit!</p>

</div>
<p class="info">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis reiciendis ea perspiciatis et tempore vero cupiditate tenetur sapiente amet nobis quo sunt, assumenda sed aperiam culpa minus velit, id quod harum adipisci, incidunt eaque vitae. Magnam expedita, laborum dignissimos doloremque odit voluptatibus officia in corporis nemo non doloribus atque quidem est earum provident magni repudiandae natus reiciendis placeat sunt sit unde distinctio modi rem. Qui dolorem quibusdam rerum enim voluptates consequatur neque alias ipsam deleniti optio, animi perferendis voluptas magni molestias tempora temporibus, sapiente deserunt explicabo porro. Debitis nam veritatis, fuga eligendi porro molestias aliquam inventore, id voluptates nisi sit!</p>
<p class="info">support emails - help@clothing.com,
customersupport@clothimg.com</p>
<p class="info">telephone - 180 00 00 001, 180 00 00 002</p>
<div class="footer-social-container">
    <div>
        <a href="#" class="social-link">terms & services</a>
        <a href="#" class="social-link">privacy page</a>
    </div>
    <div>
        <a href="#" class="social-link">instagram</a>
        <a href="#" class="social-link">facebook</a>
        <a href="#" class="social-link">twitter</a>
    </div>
</div>
<p class="footer-credit">clothing,best apperals online Store</p>
`;
}

createfooter();